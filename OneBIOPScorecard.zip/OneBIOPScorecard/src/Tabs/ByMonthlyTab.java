package Tabs;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import Database.DBConnect;

public class ByMonthlyTab extends JPanel {

	private JTable table = new JTable();

	public ByMonthlyTab() {
		table = new JTable();

		setTable();

		ListSelectionModel listSelectionModel = table.getSelectionModel();
		listSelectionModel.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				ListSelectionModel lsm = (ListSelectionModel) e.getSource();
			}
		});

		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Edit Table (If double clicked)
		table.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.getClickCount() == 2) {

					int row = table.getSelectedRow();
					int column = table.getColumnCount();
				}
			}
		});
		this.setLayout(new BorderLayout(0, 0));

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		this.add(scrollPane, BorderLayout.CENTER);


	}

	public void setTable() {
		DBConnect db = new DBConnect();
		table = new JTable(db.retrieveScorecardMonthly());
		table.getTableHeader().setReorderingAllowed(false);
	}



	public JPanel monthlyTab() {



		return this;
	}

}

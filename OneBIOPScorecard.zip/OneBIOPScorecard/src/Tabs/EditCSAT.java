package Tabs;

import javax.swing.JFrame;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

import Database.DBConnect;

public class EditCSAT implements ActionListener {
	JFrame frame = new JFrame("Edit");
	private JTextField txtCSAT;
	DBConnect db = new DBConnect();

	private JComboBox cmbName;
	private JTextField txtDate;
	private JLabel lblEditCSAT;
	private JLabel lblDate;
	private JLabel lblCSAT;
	private JLabel lblName;
	private JButton btnPickDate;
	private JButton btnEdit;
	private String name;
	private Date date;
	private Double csat;

	public EditCSAT(String name, Date date, Double csat) {
		this.name = name;
		this.date = date;
		this.csat = csat;
		
		ActListener act = new ActListener();

		frame.setSize(400, 400);
		frame.getContentPane().setLayout(new MigLayout("", "[][][grow]", "[][][][][][][][]"));

		lblEditCSAT = new JLabel("Edit CSAT");
		lblEditCSAT.setFont(new Font("Tahoma", Font.BOLD, 18));
		frame.getContentPane().add(lblEditCSAT, "cell 1 1");

		lblName = new JLabel("Name");
		frame.getContentPane().add(lblName, "cell 1 3,alignx trailing");

		cmbName = new JComboBox(db.getEmployeeFullName().toArray());

		frame.getContentPane().add(cmbName, "cell 2 3,growx");

		lblDate = new JLabel("Date");
		frame.getContentPane().add(lblDate, "cell 1 4,alignx trailing");

		frame.setVisible(true);

		AutoCompleteDecorator.decorate(this.cmbName);

		cmbName.setSelectedItem(name);

		txtDate = new JTextField();
		frame.getContentPane().add(txtDate, "cell 2 4,growx");
		txtDate.setColumns(10);

		btnPickDate = new JButton("Pick");
		frame.getContentPane().add(btnPickDate, "cell 2 5,growx");

		lblCSAT = new JLabel("CSAT");
		frame.getContentPane().add(lblCSAT, "cell 1 6,alignx trailing");

		txtCSAT = new JTextField();
		frame.getContentPane().add(txtCSAT, "cell 2 6,growx");
		txtCSAT.setColumns(10);

		cmbName.setSelectedItem(name);
		txtCSAT.setText(csat.toString());
		txtDate.setText(date.toString());

		btnEdit = new JButton("Edit");
		btnEdit.addActionListener(act);

		btnPickDate.addActionListener(act);

		frame.getContentPane().add(btnEdit, "cell 2 7,growx");

	}

	private class ActListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			if (a.getSource() == btnEdit) {
				System.out.println(name);
				System.out.println(date);

				System.out.println(csat);

				System.out.println(cmbName.getSelectedItem().toString());

				System.out.println();

				DateFormat df = new SimpleDateFormat("yyyy-mm-dd");
				Date newDate = null;
				try {
					newDate = df.parse(txtDate.getText().toString());

				} catch (ParseException e1) {
					e1.printStackTrace();
				}

				db.editCSAT(name, date, csat, cmbName.getSelectedItem().toString(), newDate,
						Double.parseDouble(txtCSAT.getText().toString()));
			}
			
			else if(a.getSource() == btnPickDate){
				DatePicker dp = new DatePicker();
				dp.onClick(date, txtDate);
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}

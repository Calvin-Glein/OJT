package Tabs;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class AddSearch {
	
	private final TableRowSorter<TableModel> rowSorterz;
	

	public AddSearch(JTable table, TableRowSorter<TableModel> rowSorter, JTextField txtSearch, JPanel panel) {
		rowSorter = new TableRowSorter<>(table.getModel());
		
		rowSorterz = rowSorter;

		panel.add(new JScrollPane(table), BorderLayout.CENTER);

		table.setRowSorter(rowSorter);

		txtSearch.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void insertUpdate(DocumentEvent e) {
				String text = txtSearch.getText();

				if (text.trim().length() == 0) {
					rowSorterz.setRowFilter(null);
				} else {
					rowSorterz.setRowFilter(RowFilter.regexFilter("(?i)" + text));
				}
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				String text = txtSearch.getText();

				if (text.trim().length() == 0) {
					rowSorterz.setRowFilter(null);
				} else {
					rowSorterz.setRowFilter(RowFilter.regexFilter("(?i)" + text));
				}
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				throw new UnsupportedOperationException("Not supported yet.");
			}

		});

	}
}

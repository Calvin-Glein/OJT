package Tabs;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import Database.DBConnect;

public class QATab{
	
	private JPanel panel = new JPanel();
	private JTable table = new JTable();
	private JTextField txtSearch = new JTextField();
	private DBConnect db = new DBConnect();
	private TableRowSorter<TableModel> rowSorter = new TableRowSorter<>();
	
	public QATab() {
		table = new JTable();

		setTable();

		ListSelectionModel listSelectionModel = table.getSelectionModel();
		listSelectionModel.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				ListSelectionModel lsm = (ListSelectionModel) e.getSource();
			}
		});

		panel.setLayout(new BorderLayout(0, 0));

		// JScrollPane scrollPane = new JScrollPane(table);
		// scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		// this.add(scrollPane, BorderLayout.CENTER);

		panel.add(txtSearch, BorderLayout.NORTH);

		addTableListener();

		new AddSearch(table, rowSorter, txtSearch, panel);

	}

	public void setTable() {
		table = new JTable(db.retrieveQA());
		table.getTableHeader().setReorderingAllowed(false);

	}

	public JPanel getJPanel() {

		return panel;
	}

	public JTable getTable() {
		return table;
	}

	public void addTableListener() {

		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Edit Table (If double clicked)
		table.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.getClickCount() == 2) {

					int row = table.getSelectedRow();
					int column = table.getColumnCount();

					System.out.println(row + " " + column);
					String name = table.getValueAt(row, 0).toString(); 
					Date date = (Date) table.getValueAt(row, 1);
					double qa = Double.parseDouble(table.getValueAt(row, 2).toString());

	//					db.editQA(name, date, qa);
	//					
						EditQA edit = new EditQA(name, date, qa);
					
				}
			}
		});
	}

//	public void addSearchTable() {
//		rowSorter = new TableRowSorter<>(table.getModel());
//
//		add(new JScrollPane(table), BorderLayout.CENTER);
//
//		table.setRowSorter(rowSorter);
//
//		txtSearch.getDocument().addDocumentListener(new DocumentListener() {
//
//			@Override
//			public void insertUpdate(DocumentEvent e) {
//				String text = txtSearch.getText();
//
//				if (text.trim().length() == 0) {
//					rowSorter.setRowFilter(null);
//				} else {
//					rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
//				}
//			}
//
//			@Override
//			public void removeUpdate(DocumentEvent e) {
//				String text = txtSearch.getText();
//
//				if (text.trim().length() == 0) {
//					rowSorter.setRowFilter(null);
//				} else {
//					rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
//				}
//			}
//
//			@Override
//			public void changedUpdate(DocumentEvent e) {
//				throw new UnsupportedOperationException("Not supported yet."); 
//			}
//
//		});
//
//	}

}

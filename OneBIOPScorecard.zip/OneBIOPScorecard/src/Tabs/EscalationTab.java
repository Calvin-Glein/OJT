package Tabs;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import Database.DBConnect;

public class EscalationTab {
	private JPanel panel = new JPanel();

	private JTable table = new JTable();
	private JTextField txtSearch = new JTextField();
	private TableRowSorter<TableModel> rowSorter = new TableRowSorter<>();
	private DBConnect db = new DBConnect();

	public EscalationTab() {
		table = new JTable();

		setTable();

		ListSelectionModel listSelectionModel = table.getSelectionModel();
		listSelectionModel.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				ListSelectionModel lsm = (ListSelectionModel) e.getSource();
			}
		});

		panel.setLayout(new BorderLayout(0, 0));

		// JScrollPane scrollPane = new JScrollPane(table);
		// scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		// panel.add(scrollPane, BorderLayout.CENTER);

		panel.add(txtSearch, BorderLayout.NORTH);

		addTableListener();
		new AddSearch(table, rowSorter, txtSearch, panel);

	}

	public void setTable() {

		table = new JTable(db.retrieveEscalation());
		table.getTableHeader().setReorderingAllowed(false);
	}

	public JPanel getJPanel() {

		return panel;
	}

	public JTable getTable() {
		return table;
	}

	public void addTableListener() {

		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Edit Table (If double clicked)
		table.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.getClickCount() == 2) {

					int row = table.getSelectedRow();
					int column = table.getColumnCount();

					System.out.println(row + " " + column);

					System.out.println(row + " " + column);
					String name = table.getValueAt(row, 0).toString();
					Date date = (Date) table.getValueAt(row, 1);
					int escalation = Integer.parseInt(table.getValueAt(row, 2).toString());

					// db.editQA(name, date, qa);
					//
					EditEscalation edit = new EditEscalation(name, date, escalation);
				}
			}
		});
	}

}

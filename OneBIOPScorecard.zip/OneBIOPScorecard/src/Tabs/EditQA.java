package Tabs;

import javax.swing.JFrame;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

import Database.DBConnect;

public class EditQA implements ActionListener {
	JFrame frame = new JFrame("Edit");
	private JTextField txtQA;
	DBConnect db = new DBConnect();

	private JComboBox cmbName;
	private JTextField txtDate;
	private JLabel lblEditQa;
	private JLabel lblDate;
	private JLabel lblQa;
	private JLabel lblName;
	private JButton btnPickDate;
	private JButton btnEdit;
	private String name;
	private Date date;
	private Double qa;

	public EditQA(String name, Date date, Double qa) {
		this.name = name;
		this.date = date;
		this.qa = qa;
		
		ActListener act = new ActListener();

		frame.setSize(400, 400);
		frame.getContentPane().setLayout(new MigLayout("", "[][][grow]", "[][][][][][][][]"));

		lblEditQa = new JLabel("Edit QA");
		lblEditQa.setFont(new Font("Tahoma", Font.BOLD, 18));
		frame.getContentPane().add(lblEditQa, "cell 1 1");

		lblName = new JLabel("Name");
		frame.getContentPane().add(lblName, "cell 1 3,alignx trailing");

		cmbName = new JComboBox(db.getEmployeeFullName().toArray());

		frame.getContentPane().add(cmbName, "cell 2 3,growx");

		lblDate = new JLabel("Date");
		frame.getContentPane().add(lblDate, "cell 1 4,alignx trailing");

		frame.setVisible(true);

		AutoCompleteDecorator.decorate(this.cmbName);

		cmbName.setSelectedItem(name);

		txtDate = new JTextField();
		frame.getContentPane().add(txtDate, "cell 2 4,growx");
		txtDate.setColumns(10);

		btnPickDate = new JButton("Pick");
		frame.getContentPane().add(btnPickDate, "cell 2 5,growx");

		lblQa = new JLabel("QA");
		frame.getContentPane().add(lblQa, "cell 1 6,alignx trailing");

		txtQA = new JTextField();
		frame.getContentPane().add(txtQA, "cell 2 6,growx");
		txtQA.setColumns(10);

		cmbName.setSelectedItem(name);
		txtQA.setText(qa.toString());
		txtDate.setText(date.toString());

		btnEdit = new JButton("Edit");
		btnEdit.addActionListener(act);

		btnPickDate.addActionListener(act);

		frame.getContentPane().add(btnEdit, "cell 2 7,growx");

	}

	private class ActListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			if (a.getSource() == btnEdit) {
				System.out.println(name);
				System.out.println(date);

				System.out.println(qa);

				System.out.println(cmbName.getSelectedItem().toString());

				System.out.println();

				DateFormat df = new SimpleDateFormat("yyyy-mm-dd");
				Date newDate = null;
				try {
					newDate = df.parse(txtDate.getText().toString());

				} catch (ParseException e1) {
					e1.printStackTrace();
				}

				db.editQA(name, date, qa, cmbName.getSelectedItem().toString(), newDate,
						Double.parseDouble(txtQA.getText().toString()));
				JOptionPane.showMessageDialog(null, "QA data updated");
				frame.dispose();
				
				
			}
			
			else if(a.getSource() == btnPickDate){
				DatePicker dp = new DatePicker();
				dp.onClick(date, txtDate);
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}

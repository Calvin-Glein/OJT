package Tabs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;

public class DatePicker {

	JXDatePicker datePicker = new JXDatePicker();
	private JPanel datePickPanel = new JPanel();
	private final JButton btnSet = new JButton("Set");
	private JFrame calendarFrame;
	private Date dateFrom;
	private String dateString;

	public DatePicker() {

	}

	public void onClick(Date date, JTextField txtDate) {
		calendarFrame = new JFrame("Calendar");
		calendarFrame.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				calendarFrame.setEnabled(true);

			}
		});
		datePickPanel = new JPanel();
		calendarFrame.setAlwaysOnTop(true);
		calendarFrame.setBounds(400, 400, 250, 100);

		datePicker = new JXDatePicker();
		datePicker.setDate(date);
		datePicker.setFormats(new SimpleDateFormat("dd-MM-yyyy"));

		datePickPanel.add(datePicker);
		datePickPanel.add(btnSet);
		calendarFrame.getContentPane().add(datePickPanel);

		calendarFrame.setVisible(true);
		
		btnSet.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				onSet(txtDate);
			}
		});
	}

	public void onSet(JTextField txtDate) {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		dateFrom = datePicker.getDate();
		dateString = formatter.format(dateFrom);

		txtDate.setText("");

		txtDate.setText(dateString);

		calendarFrame.dispose();
		calendarFrame = new JFrame("Calendar");

	}
}

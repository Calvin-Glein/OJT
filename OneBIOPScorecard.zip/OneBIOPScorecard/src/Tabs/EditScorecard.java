package Tabs;

import javax.swing.JFrame;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

import Database.DBConnect;

public class EditScorecard implements ActionListener {
	JFrame frame = new JFrame("Edit");
	private JTextField txtTotal_Tickets;
	DBConnect db = new DBConnect();

	private JComboBox cmbName;
	private JTextField txtDate;
	private JLabel lblEditScorecard;
	private JLabel lblDate;
	private JLabel lblName;
	private JButton btnPickDate;
	private JButton btnEdit;
	private String name;
	private Date date;
	private String team;
	private int total_tickets;
	private double e2e;
	private double disputed;
	private int missed_tickets;
	private int fyr;
	private double controllable_mis;
	private double call_registration;
	
	
	private JLabel lblTotalTickets;
	private JLabel lblTeam;
	private JLabel lblEe;
	private JLabel lblDisputed;
	private JLabel lblMissedTickets;
	private JLabel lblFyr;
	private JLabel lblControllableMis;
	private JLabel lblCallRegistration;
	private JTextField txtE2E;
	private JTextField txtDisputed;
	private JTextField txtMissedTickets;
	private JTextField txtFYR;
	private JTextField txtControllableMis;
	private JTextField txtCallRegistration;
	private JComboBox cmbTeam;

	public EditScorecard(Date date, String name, String team, int total_tickets, double e2e, double disputed,
			int missed_tickets, int fyr, double controllable_mis, double call_registration) {
		this.name = name;
		this.date = date;
		this.team = team;
		this.total_tickets = total_tickets;
		this.e2e = e2e;
		this.disputed = disputed;
		this.missed_tickets = missed_tickets;
		this.fyr = fyr;
		this.controllable_mis = controllable_mis;
		this.call_registration = call_registration;

		ActListener act = new ActListener();
		
		ArrayList<String> arr_teams = new ArrayList<>();

		arr_teams.add("ASIA");
		arr_teams.add("EMEA");
		arr_teams.add("NALA");
		
		
		cmbTeam = new JComboBox(arr_teams.toArray());
		AutoCompleteDecorator.decorate(this.cmbTeam);
		cmbTeam.setSelectedItem(team);

		frame.setSize(500, 500);
		frame.getContentPane().setLayout(new MigLayout("", "[][][grow]", "[][][][][][][][][][][][][][][]"));

		lblEditScorecard = new JLabel("Edit Scorecard");
		lblEditScorecard.setFont(new Font("Tahoma", Font.BOLD, 18));
		frame.getContentPane().add(lblEditScorecard, "cell 1 1");

		lblName = new JLabel("Name");
		frame.getContentPane().add(lblName, "cell 1 3,alignx trailing");

		cmbName = new JComboBox(db.getEmployeeFullName().toArray());

		frame.getContentPane().add(cmbName, "cell 2 3,growx");

		frame.setVisible(true);

		AutoCompleteDecorator.decorate(this.cmbName);
		
		


		cmbName.setSelectedItem(name);

		cmbName.setSelectedItem(name);

		lblTeam = new JLabel("Team");
		frame.getContentPane().add(lblTeam, "cell 1 4,alignx trailing");


		frame.getContentPane().add(cmbTeam, "cell 2 4,growx");

		lblDate = new JLabel("Date");
		frame.getContentPane().add(lblDate, "cell 1 5,alignx trailing");

		txtDate = new JTextField();
		frame.getContentPane().add(txtDate, "cell 2 5,growx");
		txtDate.setColumns(10);
		txtDate.setText(date.toString());

		btnPickDate = new JButton("Pick");
		frame.getContentPane().add(btnPickDate, "cell 2 6,growx");

		btnPickDate.addActionListener(act);

		lblTotalTickets = new JLabel("Total Tickets");
		frame.getContentPane().add(lblTotalTickets, "cell 1 7,alignx trailing");
		

		txtTotal_Tickets = new JTextField();
		frame.getContentPane().add(txtTotal_Tickets, "cell 2 7,growx");
		txtTotal_Tickets.setColumns(10);
		txtTotal_Tickets.setText(Integer.toString(total_tickets));

		lblEe = new JLabel("E2E");
		frame.getContentPane().add(lblEe, "cell 1 8,alignx trailing");

		txtE2E = new JTextField();
		frame.getContentPane().add(txtE2E, "cell 2 8,growx");
		txtE2E.setColumns(10);
		txtE2E.setText(Double.toString(e2e));

		lblDisputed = new JLabel("Disputed");
		frame.getContentPane().add(lblDisputed, "cell 1 9,alignx trailing");

		txtDisputed = new JTextField();
		frame.getContentPane().add(txtDisputed, "cell 2 9,growx,aligny top");
		txtDisputed.setColumns(10);
		txtDisputed.setText(Double.toString(disputed));

		lblMissedTickets = new JLabel("Missed Tickets");
		frame.getContentPane().add(lblMissedTickets, "cell 1 10,alignx trailing");

		txtMissedTickets = new JTextField();
		txtMissedTickets.setText("");
		frame.getContentPane().add(txtMissedTickets, "cell 2 10,growx,aligny top");
		txtMissedTickets.setColumns(10);
		txtMissedTickets.setText(Integer.toString(missed_tickets));

		lblFyr = new JLabel("FYR");
		frame.getContentPane().add(lblFyr, "cell 1 11,alignx trailing");

		btnEdit = new JButton("Edit");
		btnEdit.addActionListener(act);

		txtFYR = new JTextField();
		frame.getContentPane().add(txtFYR, "cell 2 11,growx,aligny top");
		txtFYR.setColumns(10);
		txtFYR.setText(Integer.toString(fyr));

		lblControllableMis = new JLabel("Controllable Mis");
		frame.getContentPane().add(lblControllableMis, "cell 1 12,alignx trailing");

		txtControllableMis = new JTextField();
		txtControllableMis.setText("");
		frame.getContentPane().add(txtControllableMis, "cell 2 12,growx");
		txtControllableMis.setColumns(10);
		txtControllableMis.setText(Double.toString(controllable_mis));

		lblCallRegistration = new JLabel("Call Registration");
		frame.getContentPane().add(lblCallRegistration, "cell 1 13,alignx trailing");

		txtCallRegistration = new JTextField();
		txtCallRegistration.setText("");
		frame.getContentPane().add(txtCallRegistration, "cell 2 13,growx");
		txtCallRegistration.setColumns(10);
		txtCallRegistration.setText(Double.toString(call_registration));

		frame.getContentPane().add(btnEdit, "cell 2 14,growx");

	}

	private class ActListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			if (a.getSource() == btnEdit) {
	

				DateFormat df = new SimpleDateFormat("yyyy-mm-dd");
				Date newDate = null;
				try {
					newDate = df.parse(txtDate.getText().toString());

				} catch (ParseException e1) {
					e1.printStackTrace();
				}

//				db.editScorecard(name, date, qa, cmbName.getSelectedItem().toString(), newDate,
//						Double.parseDouble(txtTotal_Tickets.getText().toString()));
//				JOptionPane.showMessageDialog(null, "QA data updated");
//				frame.dispose();
				
				db.editScorecard(date, name, team, total_tickets, e2e, disputed, missed_tickets, fyr, controllable_mis, call_registration, newDate, 
						cmbName.getSelectedItem().toString(), cmbTeam.getSelectedItem().toString(), Integer.parseInt(txtTotal_Tickets.getText()), Double.parseDouble(txtE2E.getText()), 
						Double.parseDouble(txtDisputed.getText()), Integer.parseInt(txtMissedTickets.getText()), 
						Integer.parseInt(txtFYR.getText()), Double.parseDouble(txtControllableMis.getText()), Double.parseDouble(txtCallRegistration.getText()));

				JOptionPane.showMessageDialog(null, "Scorecard data updated.");
				frame.dispose();
			}

			else if (a.getSource() == btnPickDate) {
				DatePicker dp = new DatePicker();
				dp.onClick(date, txtDate);
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}

package View;
import java.awt.BorderLayout;

import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import Tabs.CSATTab;
import Tabs.EmployeeTab;
import Tabs.EscalationTab;
import Tabs.MonthlyTab;
import Tabs.QATab;
import Tabs.TeamTab;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GUIScorecard extends JFrame {



	public GUIScorecard() {
		this.setTitle("Scorecard");
		this.setPreferredSize(new Dimension(1200, 800));
		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setVisible(true);

		// frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setLocationRelativeTo(null);

		
		initializeTabbedPane();
	}

	public void initializeTabbedPane() {

		JTabbedPane jtp = new JTabbedPane();
		jtp.addTab("Monthly", new MonthlyTab());
		jtp.addTab("Employee", new EmployeeTab());
		jtp.addTab("Team", new TeamTab());
		jtp.addTab("QA", new QATab());
		jtp.addTab("Escalation", new EscalationTab());
		jtp.addTab("CSAT", new CSATTab());

		add(jtp);
	}
	

	

	
	
	
	
}
